from django.contrib import admin
from . models import Estate,Apartment



# Register your models here.
admin.site.register(Estate)
admin.site.register(Apartment)